﻿USE [Projeto_Livraria]
GO

/****** Object: Table [dbo].[LIVRO] Script Date: 25/02/2019 16:04:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[LIVRO] (
    [Id]             INT             IDENTITY (1, 1) NOT NULL PRIMARY KEY,
    [ISBN]           NVARCHAR (100)  NOT NULL,
    [Autor]          NVARCHAR (100)  NOT NULL,
    [Nome]           NVARCHAR (100)  NOT NULL,
    [Preco]          DECIMAL (18, 2) NOT NULL,
    [DadaPublicacao] DATETIME        NULL,
    [ImagemCapa]     NVARCHAR(MAX)   NULL
);

GO

INSERT INTO [dbo].[LIVRO] VALUES (
  '978-85-94318-08-4','Lewis Carrol','Alice no país das maravilhas',24, '07/12/2007' ,
  (SELECT * FROM OPENROWSET(BULK 'C:\WebAPI\WebApi_Livraria\Imagens\AliceNoPaísDasMaravilhas.jpg', SINGLE_BLOB) AS A));

  
INSERT INTO [dbo].[LIVRO] VALUES (
  '978-85-94318-00-8','Nicolau Maquiavel','O príncipe',27, '07/12/2007' ,
  (SELECT * FROM OPENROWSET(BULK 'C:\WebAPI\WebApi_Livraria\Imagens\OPríncipe.jpg', SINGLE_BLOB) AS A));

  
INSERT INTO [dbo].[LIVRO] VALUES (
  '978-85-94318-07-7','Jane Austen','Razão e sensibilidade',23, '07/12/2007' ,
  (SELECT * FROM OPENROWSET(BULK 'C:\WebAPI\WebApi_Livraria\Imagens\RazãoESensibilidade.jpg', SINGLE_BLOB) AS A));


  
INSERT INTO [dbo].[LIVRO] VALUES (
  '978-85-94318-09-1','Franz Kafka','A metamorfose',19, '07/12/2007' ,
  (SELECT * FROM OPENROWSET(BULK 'C:\WebAPI\WebApi_Livraria\Imagens\AMetamorfose.jpg', SINGLE_BLOB) AS A));

  
INSERT INTO [dbo].[LIVRO] VALUES (
  '978-85-94318-10-7','Arthur Conan Doyle','Um estudo em vermelho',25, '07/12/2007' ,
  (SELECT * FROM OPENROWSET(BULK 'C:\WebAPI\WebApi_Livraria\Imagens\UmEstudoEmVermelho.jpg', SINGLE_BLOB) AS A));


  select * from [dbo].[LIVRO];